from flask import Flask, request, render_template
import pickle
import numpy as np

app = Flask(__name__)

# Load the trained model
model = pickle.load(open(r'C:\Users\Atul Khose\OneDrive\Desktop\Real Estate\model_pickle.pkl', 'rb'))

# List of locations
locations = [
    'Koregaon Park', 'Viman Nagar', 'Hinjewadi', 'Kothrud', 'Camp',
    'Pimple Saudagar', 'Baner', 'Wakad', 'Aundh', 'Shivajinagar',
    'Hadapsar', 'Mundhwa', 'Magarpatta City', 'Bhugaon', 'Undri'
]

@app.route('/')
def index():
    return render_template('index.html', locations=locations)

@app.route('/predict', methods=['POST'])
def predict():
    total_sqft = float(request.form['total_sqft'])
    bath = int(request.form['bath'])
    balcony = int(request.form['balcony'])
    bhk = int(request.form['bhk'])
    location = request.form['location']
    
    # Convert location to encoded value
    location_encoded = locations.index(location) + 1
    
    # Prepare the input for the model
    input_features = np.array([[total_sqft, bath, balcony, bhk, location_encoded]])
    
    # Predict the price
    prediction = model.predict(input_features)[0]
    
    return render_template('result.html', prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True)
