from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import numpy as np
import joblib
from sklearn.preprocessing import StandardScaler

# Initialize Flask app
app = Flask(__name__)

# Load the trained model, scaler, and LabelEncoder
model = joblib.load('random_forest_model-Copy1.pkl')
scaler = joblib.load('scaler-Copy1.pkl')  # Load the scaler
le = joblib.load('location_encoder-Copy1.pkl')  # Load the LabelEncoder for location

# Define location options (location names with their encoded values)
locations = {
    'Aundh': 0,
    'Kothrud': 1,
    'Magarpatta': 2,
    'Sadashiv Peth': 3,
    'Wakad': 4,
    'Pimpri-Chinchwad': 5,
    'Pashan': 6,
    'Kharadi': 7,
    'Baner': 8,
    'Hinjawadi': 9,
    'Shivaji Nagar': 10,
    'Viman Nagar': 11,
    'Hadapsar': 12
}

# Furnishing options
furnishing_options = {
    'Unfurnished': 0,
    'Semi-Furnished': 1,
    'Fully Furnished': 2
}

# Route for the index page
@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        # Get the form data from the HTML form
        try:
            total_sqft = float(request.form["total_sqft"])
            bath = int(request.form["bath"])
            balcony = int(request.form["balcony"])
            size = int(request.form["size"])
            location = request.form["location"]
            location_encoded = locations[location]  # Encode the location
            furnishing = request.form["furnishing"]
            furnishing_encoded = furnishing_options[furnishing]  # Encode furnishing
            
            # Debugging: print input values
            print(f"Input Values - Total Sqft: {total_sqft}, Bath: {bath}, Balcony: {balcony}, Size: {size}, Location: {location}, Furnishing: {furnishing}")

            # Prepare the input data for prediction
            input_data = np.array([[total_sqft, bath, balcony, size, location_encoded, furnishing_encoded]])

            # Debugging: print raw input data
            print(f"Raw Input Data: {input_data}")

            # Scale the input data using the saved scaler
            input_data_scaled = scaler.transform(input_data)

            # Debugging: print scaled input data
            print(f"Scaled Input Data: {input_data_scaled}")

            # Make prediction using the RandomForest model
            prediction = model.predict(input_data)

            # Debugging: print the prediction
            print(f"Prediction: {prediction[0]}")

            # Redirect to result page with the prediction
            return redirect(url_for('result', prediction=prediction[0]))
        
        except Exception as e:
            print(f"Error during prediction: {e}")
            return redirect(url_for('index'))

    return render_template("index.html", locations=locations, furnishing_options=furnishing_options)

# Route for the result page
@app.route("/result")
def result():
    # Get the prediction from the URL parameters
    prediction = request.args.get("prediction")
    return render_template("result.html", prediction=prediction)

# Run the app
if __name__ == "__main__":
    app.run(debug=True)
